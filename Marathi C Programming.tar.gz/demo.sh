_file="$1"
./translator $_file > /tmp/e
cc a0.c 2> err.txt
if [ -s "err.txt" ]
then
	rm output
	flex parser.lex > /tmp/e1
	cc -c lex.yy.c > /tmp/e1
	cc -c Split_Mechanism.c > /tmp/e1
	cc Split_Mechanism.o lex.yy.o -o error_parser > /tmp/e1
	./error_parser err.txt output > /tmp/e1
	#echo -e "\nOutput : \n============\n" 
	cat output
	#echo -e ""
	rm *.o
else
	./a.out 
fi


