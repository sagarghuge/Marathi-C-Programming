import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.tree.*;
import java.util.*;
class Explorer extends JInternalFrame
{
		JTree tree;
		JScrollPane pane;
		DefaultMutableTreeNode node[];
		File drvs[];
		DefaultMutableTreeNode mc;
		Explorer(String str,JScrollPane pane)
		{
			super(str);
			show();
			mc = new DefaultMutableTreeNode("My Project");
                        File f = new File(str);
			drvs =  f.listFiles();
			node = new  DefaultMutableTreeNode[drvs.length];	
			for(int i =0;i<drvs.length;i++)
			{
				
				node[i] = new DefaultMutableTreeNode(""+drvs[i]);
				mc.add(node[i]);
			}
			for(int j=0;j<drvs.length;j++)
			{
				Runner r = new Runner(drvs[j],node[j]);	
			}
						
			tree = new JTree(mc);
			pane = new JScrollPane(tree, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

			getContentPane().add(pane);
			tree.addMouseListener(new MouseAdapter()
			{
				public void mouseClicked(MouseEvent me)
				{
					doMouseClicked(me);
				}
			
			});	
			setSize(200,200);
			setSize(350,550);
		}
		public void doMouseClicked(MouseEvent me) 
		{
			TreePath tp = tree.getPathForLocation(me.getX(),me.getY());
			if(tp != null)
			{
				String str = tp.toString();
				str = str.substring(1);
				str = str.substring(0,str.length()-1);
				System.out.print("\n\t Path  : "+str);
				
				StringTokenizer token = new StringTokenizer(str,",");
				String path="";
				while(token.hasMoreTokens())
				{
					path=path+token.nextToken();
					if(token.hasMoreTokens())
					{
						path=path+"/";
					}
				}
				System.out.print("\n\t Extracted Path  : "+path);
				
				if(path.startsWith("My"))
				{
					System.out.print("\n\n\t K : "+path);
					int k = path.indexOf("/");
					path = path.substring(k+1);
					/*k = path.indexOf("/");
					path = path.substring(k+1);*/
					System.out.print("\n\n\t K : "+path);
					
				}
				path=removeSpaces(path);
				System.out.print("\n\t I am here : "+path);
				File l = new File(path);
				
				
			}
		}
		public String removeSpaces(String st)
		{
			String s,s1;
			while(true)
			{
				int t = st.indexOf("/ ");
				s=st.substring(0,t+1);
				s1=st.substring(t+2);
				st=s+s1;
				if(new File(st).exists())
				{
					return st;
				}
				
			}	
		}
		class Runner implements Runnable
		{
			Thread t;
			String name;
			File f;
			DefaultMutableTreeNode ne;
			Runner(File fl,DefaultMutableTreeNode dmtn)
			{
				f=fl;
				ne=dmtn;
				name=f.getName();
				t = new Thread(this,name);
				t.start();
			}
			public void run()
			{
                                try{
                                    File[] flss = f.listFiles();
                                    for(int i=0;i<flss.length;i++)
                                    {
                                            getTree(flss[i],ne);
                                    }
                            }catch(Exception e)
                                {
                                
                            }
			}

		}
		public void getTree(File f,DefaultMutableTreeNode n)
		{
				
			if(f.isDirectory())
			{
				try
				{
					
					
					DefaultMutableTreeNode temp=new DefaultMutableTreeNode(f.getName());
					n.add(temp);
					
					File files[] = f.listFiles();
					for(int i=0;i<files.length;i++)
					{
						f = files[i];
						
						getTree(f,temp);
								
					}
				}
				catch(Exception e)
				{
					System.out.print("\n\t Error : "+e);
				}
			}
			else
			{
				n.add(new DefaultMutableTreeNode(f.getName()));
			}
		}
		
}

