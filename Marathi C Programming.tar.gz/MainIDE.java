import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import javax.swing.*;
import javax.swing.undo.UndoManager;
import java.awt.Color;
import java.awt.color.ColorSpace;
import javax.swing.text.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.io.*;
import java.util.*;
import javax.swing.border.Border;
class Mydialog extends JDialog implements ActionListener
{
	Panel p1,p2;
	JTextArea tf,tf1;
	Label l1,l2,l3;
	Button b1,b2;
	MainIDE w;
	String what;
	int start_p=0;
	final static Color  FOUND_C = Color.YELLOW;
	final static Color  SEL_C = Color.GRAY;
	final Highlighter hi1 = new DefaultHighlighter();
	final Highlighter hi2 = new DefaultHighlighter();
	final Highlighter.HighlightPainter painter1= new DefaultHighlighter.DefaultHighlightPainter(FOUND_C);
	final Highlighter.HighlightPainter painter2= new DefaultHighlighter.DefaultHighlightPainter(SEL_C);
	JTree jtr;

        Dimension d;
	public Mydialog(Frame f,boolean t ,MainIDE z,String name)
	{
		super(f,t);
		w=z;

		what=name;
		p1=new Panel();
		p2=new Panel();
		p1.setLayout(new GridLayout(2,2));
		if(what.equals("replace")){
			l1=new Label("Find what:");
		}else if(what.equals("save")){
			l1=new Label("संग्रहित करा फाईल name:");
		}else if(what.equals("saveas")){
			l1=new Label("संग्रहित करा As फाईल name:");
		}else if(what.equals("शोधा")){
			l1=new Label("शब्द शोधा :");
		}else if(what.equals("createproject")){
			l1=new Label("प्रकल्प Name:");
		}p1.add(l1);
                d = Toolkit.getDefaultToolkit().getScreenSize();
                int x=400,y=200;
                setLocation((int)(d.getWidth()-x)/2,((int)d.getHeight()-y)/2);
                tf=new JTextArea();
		tf.setSize(20,1);
		tf.addKeyListener(new KeyAdapter(){
				public void keyPressed(KeyEvent ke){
				w.text_select_flag=4;
				w.keyPressed(ke);
				}
				public void keyReleased(KeyEvent ke){
				w.keyReleased(ke);
				}
				});	
		p1.add(tf);
		//p1.add(new JSeparator(SwingConstants.VERTICAL));
		//l3=new Label("");
		//p1.add(l3);
		if(what.equals("replace")){
			l2=new Label("Replace");
			p1.add(l2);
			tf1=new JTextArea();
			tf1.setSize(5,0);
                        tf1.setBackground(Color.lightGray);
			tf1.addKeyListener(new KeyAdapter(){
					public void keyPressed(KeyEvent ke){
					w.text_select_flag=3;
					w.keyPressed(ke);
					}
					public void keyReleased(KeyEvent ke){
					w.keyReleased(ke);
					}
					});
			p1.add(tf1);
		}
		p2.setLayout(new FlowLayout());
		setLayout(new BorderLayout());
		add(p1,"North");
		b2=new Button("OK");
		b2.addActionListener(this);
		p2.add(b2);
		b1=new Button("Cancel");
		b1.addActionListener(this);
		p2.add(b1);
		add(p2,"South");
		w.sta.setHighlighter(hi1);
	}
	public void search() {
		//hilit.removeAllHighlights();
		w.sta.setSelectionColor(Color.green);
		String s = tf.getText();
		if (s.length() <= 0) {
			System.out.println("Nothing to search");
			return;
		}

		String content = w.sta.getText();
		int index = content.indexOf(s,start_p);
		int end = index + s.length();
		if (index >= 0) {   // match found
			if(start_p==0){
				while(index>=0){
					try {
						start_p=end;
						hi1.addHighlight(index, end, painter1);
						index = content.indexOf(s,start_p);
						end = index + s.length();
					} catch (BadLocationException e) {
						e.printStackTrace();
					}
				}
				start_p=0;
				index = content.indexOf(s,start_p);
				end = index + s.length();
				//w.sta.setHighlighter(hi2);
			}
			//try{
			start_p=end;
			//w.sta.setEditable(true);
			//hi2.addHighlight(index,end,painter2);
			w.sta.select(index,end);
			w.sta.setCaretPosition(end);
			l3.setText("Found");
			//} catch (BadLocationException e) {
			//      e.printStackTrace();
			//}
		} else {
			l3.setText("Not found");
		}
	}


	public void actionPerformed(ActionEvent k)
	{
		if(k.getActionCommand().equals("Cancel"))
		{
			hi1.removeAllHighlights();
			//hi2.removeAllHighlights();
			this.dispose();
		}
		if(k.getActionCommand().equals("OK"))
		{
			if(what.equals("replace")){
				String Rwhat=tf.getText();
				String Rwith=tf1.getText();
				String txt=w.sta.getText();
				String ntxt=txt.replaceAll(Rwhat,Rwith);
				w.sta.setText(ntxt);
				this.dispose();
			}else if(what.equals("save") || what.equals("saveas")){
				String data=w.sta.getText();
				System.out.println(data);
				w.file_name=tf.getText();
				System.out.print(w.path2);
				w.jtabbedpane_main.setTitleAt(w.jtabbedpane_main.getSelectedIndex(),w.file_name);
				String path=w.path2+"/marathisource/"+w.file_name+".क";/*file extion to be given*/
				try{    
					w.file_name=tf.getText();
					FileOutputStream fout1=new FileOutputStream(path);
					PrintStream ps=new PrintStream(fout1);	
					ps.print(data);
					fout1.close();
				}catch(Exception cue){
					System.out.println("file not found");//change
				}
				this.dispose();

			}else if(what.equals("find")){
				search();
			}else if(what.equals("createproject")){

				//new NewProject(tf);

				/*(new फाईल("./Marathiprojects")).mkdir();
				  w.path2=new String("./Marathiprojects/"+tf.getText());
				  System.out.println(w.path2);
				  if((new फाईल("./Marathiprojects/"+tf.getText())).exists()){
				  l3.setText("प्रकल्प name Already Exists");
				  }else{
				  l3.setText("/n");
				  (new फाईल("./Marathiprojects/"+tf.getText()+"/marathisource")).mkdirs();
				  (new फाईल("./Marathiprojects/"+tf.getText()+"/migratedCcodes")).mkdirs();
				  this.dispose();
				  }*/
			}
		}

	}
}

public class MainIDE extends JFrame implements KeyListener,ActionListener
{
        JTree tree;
	JMenuBar menubar;
	JMenu jmenu_file,jmenu_edit,jmenu_view,jmenu_run,jmenu_debug,jmenu_help;
	JToolBar main_toolbar;
	JButton bnew,bsave,bopen,bcopy,bpaste,bcut,bprint,bundo,bredo,bfind,breplace,brun;
	JInternalFrame jinteral_frame_output,jinternal_frame_exlore;
	JTabbedPane jtabbedpane_main;
	JSplitPane jsplitpane_output_combine,jsplitpane_project_tabbedpane;
	JTextArea jtextarea_main[],ta,jtextarea_output;
	JScrollPane jscrollpane_tabbed,jscrollpane_output,jscrollpane_explore;
	JPanel   line_number_textarea,base_panel,upper_panel,lower_panel;
	String clipboard,path,file_name,path2;
	UndoManager m_undoManager = new UndoManager();
	RunCommand cd = new RunCommand();
	int releasedkey;
	JTextArea sta;
	Font fonts;
	int val,v,h, flag = 0,save_flag,prev_key;
	int text_select_flag=1,explorer_flag=0;
	Mydialog c;
        File fd;
	NewProject p;
	int index = 0,count = 500,track = 0;
	String tab_name;
	File fdir;
	int[] save_flag_f,close_flag;
        JScrollPane pane;
        DefaultMutableTreeNode node[];
	File drvs[];
	DefaultMutableTreeNode mc;
        JMenuItem openfile;
	public MainIDE()
	{

		this.getContentPane().setLayout(new BorderLayout());
		save_flag_f=new int[128];
                close_flag = new int[128];
		menubar = new JMenuBar();

		// for multiple tab

		jtextarea_main= new JTextArea[count];
		System.out.print(count);
		jtextarea_main[index] = new JTextArea();    
		jtextarea_main[index].addKeyListener(this);


		jmenu_file = new JMenu("फाईल");
		jmenu_edit = new JMenu("एडीट");
		jmenu_view = new JMenu("पहा");
		jmenu_run = new JMenu("चालवा");
		jmenu_debug = new JMenu("पडताळा");
		jmenu_help = new JMenu("मदत");

		//adding menu items to Menu File
		JMenuItem createproject,openproject,save,saveas,close,closetab,newfile,pagesetup,print;

		jmenu_file.add(createproject = new  JMenuItem("नविन प्रकल्प",new ImageIcon("Resource/new-pro.gif")));
		jmenu_file.add(newfile = new  JMenuItem("नविन फाईल",new ImageIcon("Resource/new.jpg")));
		jmenu_file.add(openproject = new  JMenuItem("उघडा प्रकल्प",new ImageIcon("Resource/open.gif")));
		jmenu_file.add(openfile = new  JMenuItem("उघडा फाईल"));
		jmenu_file.addSeparator();
		jmenu_file.add(save = new  JMenuItem("संग्रहित करा",new ImageIcon("Resource/save.gif")));
		jmenu_file.add(saveas = new  JMenuItem("असे संग्रहित करा",new ImageIcon("Resource/saveas.gif")));  
		jmenu_file.addSeparator(); 
		//jmenu_file.add(pagesetup = new  JMenuItem("Page Setup",new ImageIcon("Resource/page-setup.gif")));
		//jmenu_file.add(print = new  JMenuItem("Print",new ImageIcon("Resource/print.gif")));
                jmenu_file.add(closetab = new JMenuItem("Close Tab"));
		jmenu_file.add(close = new  JMenuItem("बंद करा",new ImageIcon("Resource/close.gif")));    

		menubar.add(jmenu_file);

		//adding menu items to Menu Edit

		JMenuItem cut,copy,paste,del,selectall,undo,redo,find,replace;

		jmenu_edit.add(undo = new  JMenuItem("पु्व्रवत करा",new ImageIcon("Resource/undo.gif")));
		jmenu_edit.add(redo = new  JMenuItem("परत करा",new ImageIcon("Resource/redo.gif")));
		jmenu_edit.addSeparator();
		jmenu_edit.add(cut = new  JMenuItem("कट",new ImageIcon("Resource/cut.gif")));
		jmenu_edit.add(copy = new  JMenuItem("कॉपी",new ImageIcon("Resource/copy.gif")));
		jmenu_edit.add(paste = new  JMenuItem("पैस्ट",new ImageIcon("Resource/paste.gif")));
		jmenu_edit.addSeparator();
		jmenu_edit.add(del = new JMenuItem("मिटवा"));
		jmenu_edit.add(find = new  JMenuItem("शोधा",new ImageIcon("Resource/find.gif")));
		jmenu_edit.add(replace = new  JMenuItem("Replace",new ImageIcon("Resource/replace.gif")));
		jmenu_edit.addSeparator();
		jmenu_edit.add(selectall = new JMenuItem("Select All",new ImageIcon("Resource/selectall.gif")));

		menubar.add(jmenu_edit);

		//adding menu items to Menu View

		JCheckBoxMenuItem showline_number,showeditor_toolbar,fullscreen,statusbar;
		JMenu toolbar ;
		JCheckBoxMenuItem tnewfile,trun,tdebug,tfind,tundo,tredo;
		jmenu_view.add(toolbar = new JMenu("Toolbars"));
                toolbar.setBounds(0, 0, this.getWidth(), 10);

		//adding menuitem to toolbar menuitem
		toolbar.add(tnewfile = new JCheckBoxMenuItem("फाईल"));
		toolbar.add(trun = new JCheckBoxMenuItem("चालवा"));
		toolbar.add(tdebug = new JCheckBoxMenuItem("पडताळा"));
		toolbar.add(tfind = new JCheckBoxMenuItem("Find"));
		toolbar.add(tundo = new JCheckBoxMenuItem("पु्व्रवत करा"));
		toolbar.add(tredo = new JCheckBoxMenuItem("परत करा"));

		jmenu_view.add(showeditor_toolbar = new JCheckBoxMenuItem("ShowEditor Toolbar"));
		jmenu_view.add(showline_number = new JCheckBoxMenuItem("ShowLine Number"));
		jmenu_view.add(statusbar = new JCheckBoxMenuItem("Show StatusBar"));
		jmenu_view.add(fullscreen = new JCheckBoxMenuItem("Fullscreen"));

		menubar.add(jmenu_view);
		//adding menu items to Menu चालवा
		JMenuItem runmain_project,buildmain_project,runfile,compilefile,validatefile,stopbuildrun,cleanandbuild,setmainproject,checkfile;

		jmenu_run.add(runmain_project = new JMenuItem("चालवा मुख्य प्रकल्प",new ImageIcon("Change icon here")));
		jmenu_run.add(buildmain_project = new JMenuItem("बनवा मुख्य प्रकल्प",new ImageIcon("Change icon here")));
		jmenu_run.add(cleanandbuild = new JMenuItem("सुरुवातीपासून बनवा मुख्य प्रकल्प",new ImageIcon("Change icon here")));
		jmenu_run.add(setmainproject = new JMenuItem("निश्चित मुख्य प्रकल्प"));
		jmenu_run.addSeparator();
		jmenu_run.add(runfile = new JMenuItem("चालवा फाईल"));
		jmenu_run.add(compilefile = new JMenuItem("संकलित फाईल"));
		jmenu_run.add(checkfile = new JMenuItem("चेक फाईल",new ImageIcon("Change icon here")));
		jmenu_run.add(stopbuildrun = new JMenuItem("थांबवा बनवा/चालवा"));

		//Adding actionlistener to all run menu
		runmain_project.addActionListener(this);
		buildmain_project.addActionListener(this);
		cleanandbuild.addActionListener(this);
		setmainproject.addActionListener(this);
		runfile.addActionListener(this);
		compilefile.addActionListener(this);
		checkfile.addActionListener(this);
		stopbuildrun.addActionListener(this);


		menubar.add(jmenu_run);
		//adding menu items to Menu पडताळा

		JMenuItem debugfile,debugmain_project,pause,cont,newwatch;

		jmenu_debug.add(debugmain_project = new JMenuItem("पडताळा मुख्य प्रकल्प",new ImageIcon("Change icon here")));
		jmenu_debug.add(debugfile = new JMenuItem("पडताळा फाईल",new ImageIcon("Change icon here")));
		jmenu_debug.addSeparator();
		jmenu_debug.add(pause = new JMenuItem("Pause",new ImageIcon("Change icon here")));
		jmenu_debug.add(cont = new JMenuItem("Continue",new ImageIcon("Change icon here")));
		jmenu_debug.add(newwatch = new JMenuItem("नविन Watch",new ImageIcon("Change icon here")));

		menubar.add(jmenu_debug);
		//adding menu items to Menu मदत

		JMenuItem aboutus,contenthelp,keyboardshortcutcard;

		jmenu_help.add(contenthelp = new JMenuItem("Content मदत"));
		jmenu_help.add(keyboardshortcutcard = new JMenuItem("Keyboard Shortcut Card"));
		jmenu_help.addSeparator();
		jmenu_help.add(aboutus = new JMenuItem("About Us"));

		menubar.add(jmenu_help);

		setJMenuBar(menubar);

		//Tool Bar creation

		main_toolbar = new JToolBar("ToolBar");
		main_toolbar.setFloatable(false);

		this.getContentPane().add(main_toolbar,BorderLayout.NORTH);

		bnew = new JButton(new ImageIcon("Resource/new.gif"));
		bnew.setToolTipText("नविन फाईल");
		bnew.setActionCommand("नविन");
		bnew.setBorderPainted(false);

		bsave = new JButton(new ImageIcon("Resource/save.gif"));
		bsave.setToolTipText("संग्रहित करा");
		bsave.setActionCommand("संग्रहित करा");
		bsave.setBorderPainted(false);


		bopen = new JButton(new ImageIcon("Resource/open.gif"));
		bopen.setToolTipText("उघडा फाईल");
		bopen.setActionCommand("उघडा फाईल");
		bopen.setBorderPainted(false);
                

		bcopy = new JButton(new ImageIcon("Resource/copy.gif"));
		bcopy.setToolTipText("कॉपी");
		bcopy.setActionCommand("कॉपी");
		bcopy.setBorderPainted(false);

		bpaste = new JButton(new ImageIcon("Resource/paste.gif"));
		bpaste.setToolTipText("पैस्ट");
		bpaste.setActionCommand("पैस्ट");
		bpaste.setBorderPainted(false);

		bcut = new JButton(new ImageIcon("Resource/cut.gif"));
		bcut.setToolTipText("कट");
		bcut.setActionCommand("कट");		
		bcut.setBorderPainted(false);

		bprint = new JButton(new ImageIcon("Resource/print.gif"));
		bprint.setToolTipText("Print page");
		bprint.setActionCommand("Print");		
		bprint.setBorderPainted(false);

		bundo = new JButton(new ImageIcon("Resource/undo.gif"));
		bundo.setToolTipText("पु्व्रवत करा");
		bundo.setActionCommand("पु्व्रवत करा");		
		bundo.setBorderPainted(false);

		bredo = new JButton(new ImageIcon("Resource/redo.gif"));
		bredo.setToolTipText("परत करा");
		bredo.setActionCommand("परत करा");		
		bredo.setBorderPainted(false);

		bfind = new JButton(new ImageIcon("Resource/find.gif"));
		bfind.setToolTipText("शोधा");
		bfind.setActionCommand("शोधा");
		bfind.setBorderPainted(false);               

		breplace = new JButton(new ImageIcon("Resource/replace.gif"));
		breplace.setToolTipText("Replace");
		breplace.setActionCommand("Replace");		
		breplace.setBorderPainted(false);

		brun = new JButton(new ImageIcon("Change Icon here"));
		brun.setToolTipText("चालवा प्रकल्प");
		brun.setActionCommand("चालवा");
		brun.setBorderPainted(false);

		// Adding Listener to buttons

		bnew.addActionListener(this);
		bsave.addActionListener(this);
		bopen.addActionListener(this);
		bcopy.addActionListener(this);
		bpaste.addActionListener(this);
		bcut.addActionListener(this);
		bprint.addActionListener(this);
		bundo.addActionListener(this);
		bredo.addActionListener(this);
		bfind.addActionListener(this);
		breplace.addActionListener(this);
		brun.addActionListener(this);
		openfile.addActionListener(this);
                openproject.addActionListener(this);
		newfile.addActionListener(this);
		save.addActionListener(this);
		saveas.addActionListener(this);
		cut.addActionListener(this);
		copy.addActionListener(this);
		del.addActionListener(this);
                closetab.addActionListener(this);
		close.addActionListener(this);
		undo.addActionListener(this);
		redo.addActionListener(this);
		paste.addActionListener(this);
		find.addActionListener(this);
		replace.addActionListener(this);
		selectall.addActionListener(this);
		createproject.addActionListener(this);

		// Adding buttons to toolbar

		main_toolbar.add(bnew);
		main_toolbar.add(bopen);
		main_toolbar.add(bsave);
		main_toolbar.add(bprint);
		main_toolbar.add(bundo);
		main_toolbar.add(bredo);
		main_toolbar.add(bcut);
		main_toolbar.add(bcopy);
		main_toolbar.add(bpaste);
		main_toolbar.add(brun); 
		main_toolbar.add(bfind);
		main_toolbar.add(breplace);


		// creating new Tabbed pane

		jtabbedpane_main = new JTabbedPane();
		sta = new JTextArea();
		sta.getDocument().addUndoableEditListener(m_undoManager);
		sta.addKeyListener(this);
		ta=sta;
		jtextarea_output = new JTextArea();

		base_panel = new JPanel();
		base_panel.setLayout(new BorderLayout());
		this.getContentPane().add(base_panel,BorderLayout.CENTER);

		jsplitpane_output_combine = new JSplitPane(JSplitPane.VERTICAL_SPLIT);

		upper_panel = new JPanel();
		lower_panel  = new JPanel();
		upper_panel.setLayout(new BorderLayout());
		lower_panel.setLayout(new BorderLayout());

		//creating scroll pane

		v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
		h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;

		jinternal_frame_exlore = new JInternalFrame("प्रकल्प",true,true,false);
		jinternal_frame_exlore.show();

                
		jinteral_frame_output = new JInternalFrame("प्रक्षेपण",true,true,false);
		jinteral_frame_output.show();

		jtextarea_output.setEditable(false);
		jscrollpane_output = new JScrollPane(jtextarea_output,v,h);
		jinteral_frame_output.add(jscrollpane_output,BorderLayout.CENTER);


		base_panel.add(jsplitpane_output_combine,BorderLayout.CENTER);

		jsplitpane_output_combine.setTopComponent(upper_panel);
		jsplitpane_output_combine.setBottomComponent(lower_panel);

		jsplitpane_project_tabbedpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);

		jsplitpane_project_tabbedpane.setLeftComponent(jinternal_frame_exlore);
		jsplitpane_project_tabbedpane.setRightComponent(jtabbedpane_main);
                jsplitpane_project_tabbedpane.setDividerLocation(200);
		jsplitpane_output_combine.setDividerLocation(450);
		upper_panel.add(jsplitpane_project_tabbedpane,BorderLayout.CENTER);

		lower_panel.add(jinteral_frame_output,BorderLayout.CENTER);


		setSize(450,450);
		show();
                setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);

	}
	public void actionPerformed(ActionEvent e)
	{

		String cmd = e.getActionCommand();
		System.out.println(cmd);
		if(cmd.equals("बंद करा"))
		{
			System.exit(0);
		}
                if(cmd.equals("उघडा प्रकल्प"))
		{
                    try{
                        
                        JFileChooser fs = new JFileChooser("./मराठीप्रकल्प/");
                        fs.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                        fs.showDialog(fs,"OK");
                        
                        if(fs.getApproveButtonText().equals("OK"))
                        {
                            openfile.setEnabled(false);
                            fd = fs.getSelectedFile();
                            String get = fd.getAbsolutePath();
                            System.out.print(get);
                            mc = new DefaultMutableTreeNode(fd.getName());
                            File f = new File(get);
                            drvs =  f.listFiles();
                            node = new  DefaultMutableTreeNode[drvs.length];
                            for(int i =0;i<drvs.length;i++)
                            {

                                    node[i] = new DefaultMutableTreeNode(""+drvs[i]);
                                    mc.add(node[i]);
                            }
                            for(int j=0;j<drvs.length;j++)
                            {
                                    Runner r = new Runner(drvs[j],node[j]);
                            }

                            tree = new JTree(mc);
                            if(explorer_flag==0){
                            explorer_flag=1;
                            }else{
                                jinternal_frame_exlore.remove(pane);
                            }
                            pane = new JScrollPane(tree, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                            pane.show();
                            jinternal_frame_exlore.add(pane);
                            jsplitpane_project_tabbedpane.setDividerLocation(201);
                            jsplitpane_project_tabbedpane.setDividerLocation(200);
                          //  getContentPane().add(pane);
                            tree.addMouseListener(new MouseAdapter()
                            {
                                    public void mouseClicked(MouseEvent me)
                                    {
                                            doMouseClicked(me);
                                    }

                            });

                            jtabbedpane_main.removeAll();
                        }
                    }catch(Exception ed){
                    openfile.setEnabled(true);
                    }

		}
                if(cmd.equals("Close Tab"))
                {
                    if(close_flag[jtabbedpane_main.getSelectedIndex()]==0)
                    {
                        int response = JOptionPane.showConfirmDialog(this, "Save Document","Confirmation Box",JOptionPane.YES_NO_CANCEL_OPTION);
                        if(response==JOptionPane.YES_OPTION)
                        {
                                c=new Mydialog(this,true,this,"save");
				c.setSize(300,150);
				if(save_flag_f[jtabbedpane_main.getSelectedIndex()]==1){
					try{
						sta=jtextarea_main[jtabbedpane_main.getSelectedIndex()];
						file_name=jtabbedpane_main.getTitleAt(jtabbedpane_main.getSelectedIndex());
						path=path2+"/marathisource/"+file_name+".m";
						System.out.println(path);
						FileOutputStream fout1=new FileOutputStream(path);
						PrintStream ps=new PrintStream(fout1);
						ps.print(sta.getText());
						fout1.close();
					}catch(Exception cue){
						System.out.println("file not found");//change
					}
				}
				if(save_flag_f[jtabbedpane_main.getSelectedIndex()]==0){
					System.out.println("inhere");
					c.setVisible(true);
					save_flag_f[jtabbedpane_main.getSelectedIndex()]=1;
				}
				text_select_flag=1;
                                int j=jtabbedpane_main.getSelectedIndex();
                                jtabbedpane_main.remove(jtabbedpane_main.getSelectedIndex());
                                for(int i=j;i<jtabbedpane_main.getTabCount();i++){
                                    jtextarea_main[i]=jtextarea_main[i+1];
                                    
                                }
                        }
                        else if(response==JOptionPane.NO_OPTION)
                        {
                            int j=jtabbedpane_main.getSelectedIndex();
                            jtabbedpane_main.remove(jtabbedpane_main.getSelectedIndex());
                            text_select_flag=1;
                             for(int i=j;i<jtabbedpane_main.getTabCount();i++){
                                jtextarea_main[i]=jtextarea_main[i+1];

                            }
                        }

                    }
                    else{
                        int j=jtabbedpane_main.getSelectedIndex();
                        jtabbedpane_main.remove(jtabbedpane_main.getSelectedIndex());
                        text_select_flag=1;
                         for(int i=j;i<jtabbedpane_main.getTabCount();i++){
                                jtextarea_main[i]=jtextarea_main[i+1];

                            }
                    }
                }
		if(cmd.equals("संग्रहित करा"))
		{
			if(track==0)
			{
				JOptionPane.showMessageDialog(this,"No फाईल to संग्रहित करा");

			}
			else{

				c=new Mydialog(this,true,this,"save");
				c.setSize(300,150);
				if(save_flag_f[jtabbedpane_main.getSelectedIndex()]==1){
					try{    
						sta=jtextarea_main[jtabbedpane_main.getSelectedIndex()];
						file_name=jtabbedpane_main.getTitleAt(jtabbedpane_main.getSelectedIndex());
						path=path2+"/marathisource/"+file_name+".m";
						System.out.println(path);
						FileOutputStream fout1=new FileOutputStream(path);
						PrintStream ps=new PrintStream(fout1);	
						ps.print(sta.getText());
						fout1.close();
					}catch(Exception cue){
						System.out.println("file not found");//change
					}
				}
				if(save_flag_f[jtabbedpane_main.getSelectedIndex()]==0){
					System.out.println("inhere");
					c.setVisible(true);
					save_flag_f[jtabbedpane_main.getSelectedIndex()]=1;
				}
				text_select_flag=1;
			}   
		}
		if(cmd.equals("संग्रहित करा as"))
		{		
			save_flag_f[jtabbedpane_main.getSelectedIndex()]=0;
			c=new Mydialog(this,true,this,"saveas"); 
			c.setSize(300,150);
			c.setVisible(true);
			save_flag_f[jtabbedpane_main.getSelectedIndex()]=1;
			text_select_flag=1;
		}
		if (cmd.equals("संकलित फाईल"))
		{
			System.out.println("Compiling फाईल");
		}
		if (cmd.equals("चालवा फाईल"))
		{
			try {

				String name_run =jtabbedpane_main.getTitleAt(jtabbedpane_main.getSelectedIndex());

                                ProcessBuilder probuilder = new ProcessBuilder("./demo.sh",name_run);
				Process process = probuilder.start(); 
				//Read out dir output
				InputStream is = process.getInputStream();
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);
				String final_cfile;
                                /*final_cfile = br.readLine();/*
                                File final_C = new File("Final_C.c");
                                FileWriter fr = new FileWriter(final_C);
                                while((final_cfile = br.readLine())!=null){
                                    fr.write(final_cfile);
                                }*/
				
				//Wait to get exit value
				int exitValue = process.waitFor();
				//System.out.println("\n\nExit Value is " + exitValue);



				/*ProcessBuilder probuilder2 = new ProcessBuilder("cc",final_cfile);
				Process process2 = probuilder2.start();
                                InputStream is2 = process2.getInputStream();
				InputStreamReader isr2 = new InputStreamReader(is2);
				BufferedReader br2 = new BufferedReader(isr2);

                                System.out.println("HIiii"+br2.readLine());

				ProcessBuilder probuilder3 = new ProcessBuilder("chmod","777","*");
				Process process3 = probuilder3.start();
                                int exitValue1 = process.waitFor();
				ProcessBuilder probuilder1 = new ProcessBuilder("./a.out");
				Process process1 = probuilder1.start(); 
				//Read out dir output
				InputStream is1 = process1.getInputStream();
				InputStreamReader isr1 = new InputStreamReader(is1);
				BufferedReader br1 = new BufferedReader(isr1);*/
				String output;
				jtextarea_output.setText("");
				jtextarea_output.append("फाइल चालवण्या योग्य \n==============================\n\n प्र‌‌क्षेपण :-\n==========\n\n");
				while ((output = br.readLine()) != null) {
					System.out.println(output);
					jtextarea_output.append(output+"\n");
				}
			}
			catch (Exception ex) {
				ex.printStackTrace();
			}


			//cd.Execute("ls");

		}
		if(cmd.equals("नविन फाईल") || cmd.equals("नविन"))
		{
                        openfile.setEnabled(true);
			if(track==0)
			{
				JOptionPane.showMessageDialog(this,"पहिले नविन प्रकल्प बनवा");

			}
			else {

				index=jtabbedpane_main.getTabCount();
				save_flag_f[index]=0;
                                close_flag[index] = 1;
				jtextarea_main[index] = new JTextArea();
				sta=jtextarea_main[index];   
				jscrollpane_tabbed = new JScrollPane(sta,v,h);

				jtabbedpane_main.add("अनामांकित "+index,jscrollpane_tabbed);
				jtextarea_main[index].addKeyListener(this);

				
			}
		}	
		if(cmd.equals("कट"))
		{
			clipboard =sta.getSelectedText();
			System.out.println("Selected Text:"+clipboard);
			sta.replaceRange(" ",sta.getSelectionStart(),sta.getSelectionEnd());
		}
		if(cmd.equals("पैस्ट"))
		{
			if(ta.getCaretPosition()==sta.getSelectionStart()||ta.getCaretPosition()==sta.getSelectionEnd()){
				sta.replaceRange(" ",sta.getSelectionStart(),sta.getSelectionEnd());
			}
			sta.insert(clipboard,ta.getCaretPosition());
		}
		if(cmd.equals("कॉपी"))
		{
			clipboard=sta.getSelectedText();
		}
		if(cmd.equals("Select All"))
		{
			sta.selectAll();
		}
		if(cmd.equals("Replace"))
		{
			c=new Mydialog(this,true,this,"replace"); 
			c.setSize(300,150);
			c.setVisible(true);
			text_select_flag=1;

		}
		if(cmd.equals("शोधा"))
		{
			c=new Mydialog(this,true,this,"शोधा");
			c.setSize(300,150);
			c.setVisible(true);
			text_select_flag=1;

		}
		if(cmd.equals("नविन प्रकल्प"))
		{
			p=new NewProject(this);
			text_select_flag=1;

		}
		if(cmd.equals("मिटवा"))
		{

			sta.replaceRange(" ",sta.getSelectionStart(),sta.getSelectionEnd());
		}
		if(cmd.equals("पु्व्रवत करा"))
		{
			try {
				m_undoManager.undo();
			}
			catch (Exception cue)
			{

				Toolkit.getDefaultToolkit().beep();
			}
		}
		if(cmd.equals("परत करा"))
		{
			try {
				m_undoManager.redo();
			}
			catch (Exception cue)
			{
				Toolkit.getDefaultToolkit().beep();
			}
		}
		if(cmd.equals("About Us"))
		{
			JDialog dlg=new JDialog(this,"About Editor");
			dlg.setVisible(true);
			dlg.setSize(300,150);
			dlg.setLayout(new GridLayout(3,1));
			dlg.add(new Label("This is Our IDE"),0,0);
			dlg.add(new Label("The code is written in Java language"),1,0);
			dlg.add(new Label("  Team Details are :  "),2,0);
		}

		if(cmd.equals("उघडा फाईल"))
		{
			if(track==0)
			{
				JOptionPane.showMessageDialog(this,"पहिले नविन प्रकल्प बनवा");

			}else{

			try{
				index=jtabbedpane_main.getTabCount();
				save_flag_f[index]=1;
				jtextarea_main[index] = new JTextArea();
				sta=jtextarea_main[index];   
				jscrollpane_tabbed = new JScrollPane(sta,v,h);

				FileDialog dlg=new FileDialog(this,"Select a फाईल",FileDialog.LOAD);
				dlg.show();
				String path=dlg.getDirectory()+dlg.getFile();
				FileInputStream fin=new FileInputStream(path);
				int n=fin.available();
				byte arr[ ]=new byte[n];
				fin.read(arr);
				fin.close();
				String str=new String(arr);
				sta.setText(str);
				jtabbedpane_main.add(dlg.getFile(),jscrollpane_tabbed);
				jtextarea_main[index].addKeyListener(this);
                                jtabbedpane_main.setSelectedIndex(index);
			}
			catch(Exception er){
				//JOptionPane.showMessageDialog(this,er);
			}
			}
		}



	}
        public void doMouseClicked(MouseEvent me)
		{
			TreePath tp = tree.getPathForLocation(me.getX(),me.getY());
			if(tp != null)
			{
				String str = tp.toString();
				str = str.substring(1);
				str = str.substring(0,str.length()-1);
				System.out.print("\n\t Path  : "+str);

				StringTokenizer token = new StringTokenizer(str,",");
				String path="";
				while(token.hasMoreTokens())
				{
					path=path+token.nextToken();
					if(token.hasMoreTokens())
					{
						path=path+"/";
					}
				}
				//System.out.print("\n\t Extracted Path  : "+path);

				if(path.startsWith("/"))
				{
					System.out.print("\n\n\t K : "+path);
					int k = path.indexOf("/");
					path = path.substring(k+1);
					/*k = path.indexOf("/");
					path = path.substring(k+1);*/
					System.out.print("\n\n\t K : "+path);

				}
				path=removeSpaces(path);
				System.out.print("\n\t I am here : "+path);
				File l = new File(path);
                                StringTokenizer token2 = new StringTokenizer(path,"/");
				String path2="";
				while(token2.hasMoreTokens())
				{
					path2=token2.nextToken();

				}
                                if(l.isFile()){
                                    int click_flag=0;
                                    try{
                                        System.out.println("@@"+click_flag+path2);
                                    for(int i=0;i<jtabbedpane_main.getTabCount();i++){
                                        if(jtabbedpane_main.getTitleAt(i).equals(path2)){
                                            jtabbedpane_main.setSelectedIndex(i);
                                            click_flag=1;
                                        }
                                    }
                                    if(click_flag==0){
                                    index=jtabbedpane_main.getTabCount();
                                    save_flag_f[index]=1;
                                    jtextarea_main[index] = new JTextArea();
                                    sta=jtextarea_main[index];
                                    jscrollpane_tabbed = new JScrollPane(sta,v,h);
                                    FileInputStream fin=new FileInputStream(path);
                                    int n=fin.available();
                                    byte arr[ ]=new byte[n];
                                    fin.read(arr);
                                    fin.close();
                                    String str1=new String(arr);
                                    sta.setText(str1);
                                    jtabbedpane_main.add(path2,jscrollpane_tabbed);
                                    jtextarea_main[index].addKeyListener(this);
                                    jtabbedpane_main.setSelectedIndex(index);
                                    }
                                    click_flag=0;
                                    }
                                    catch(Exception e2){
                                    e2.printStackTrace();}
                                }


			}
		}
		public String removeSpaces(String st)
		{
			String s,s1;
			while(true)
			{
				int t = st.indexOf("/ ");
				s=st.substring(0,t+1);
				s1=st.substring(t+2);
				st=s+s1;
				if(new File(st).exists())
				{
					return st;
				}

			}
		}
		class Runner implements Runnable
		{
			Thread t;
			String name;
			File f;
			DefaultMutableTreeNode ne;
			Runner(File fl,DefaultMutableTreeNode dmtn)
			{
				f=fl;
				ne=dmtn;
				name=f.getName();
				t = new Thread(this,name);
				t.start();
			}
			public void run()
			{
                                try{
                                    File[] flss = f.listFiles();
                                    for(int i=0;i<flss.length;i++)
                                    {
                                            getTree(flss[i],ne);
                                    }
                            }catch(Exception e)
                                {

                            }
			}

		}
		public void getTree(File f,DefaultMutableTreeNode n)
		{

			if(f.isDirectory())
			{
				try
				{


					DefaultMutableTreeNode temp=new DefaultMutableTreeNode(f.getName());
					n.add(temp);

					File files[] = f.listFiles();
					for(int i=0;i<files.length;i++)
					{
						f = files[i];

						getTree(f,temp);

					}
				}
				catch(Exception e)
				{
					System.out.print("\n\t Error : "+e);
				}
			}
			else
			{
				n.add(new DefaultMutableTreeNode(f.getName()));
			}
		}
	public void keyPressed(KeyEvent ke)
	{
		try{
                    System.out.print("index : "+jtabbedpane_main.getSelectedIndex());
                        close_flag[jtabbedpane_main.getSelectedIndex()] = 0;
			sta = jtextarea_main[jtabbedpane_main.getSelectedIndex()];}
		catch(Exception e){
                }
		int key;
		key = ke.getKeyCode();
		if(text_select_flag==2){
			ta=p.txt_projectName;

		}
		else if(text_select_flag==3){
			ta=c.tf1;
		}else if(text_select_flag==4){
			ta=c.tf;
		}
		else
			ta=sta;
		
		System.out.println("key = " + key);
		
		
		/* For keys those who have same functionality in marathi as well as english keyboard */
		/* Here, text area will not de disabled as we do not want its functionality to alter for a specific key */
/*
Key  	 Code
backspace 	8
tab 	9
enter 	10 
alt 	18
PAUSE/BREAK 19
caps lock 	20
escape 	27
page up 	33
page down 	34
end 	35
home 	36
left arrow 	37
up arrow 	38
right arrow 	39
down arrow 	40
insert 	155
delete 	127
left window key  	 524
right window key 	525
f1 	112
f2 	113
f3 	114
f4 	115
f5 	116
f6 	117
f7 	118
f8 	119
f9 	120
f10 	121
f11 	122
f12 	123
num lock 	144
scroll lock 	145
space 32
numpad = on and  + 107
numpad = on and  - 109
numpad = on and  * 106
numpad = on and  / 111

*/
		if(key == 8 || key == 9 || key == 10 || key == 18 || key ==19 || key == 27 || key == 33 ||key == 34
 || key == 35 || key == 36 || key == 37 || key == 38 || key == 39 || key == 40 || key == 155 || key == 127 || key == 524 || key == 525 || key == 112 || key == 113 || key == 114 || 
key == 115|| key == 116|| key == 117 || key == 118 || key == 119 || key == 120 || key == 121 || key == 122 || key == 123 || key == 144 || key == 145 || key == 32 || key == 107 || key ==109 || key == 106 || key == 111)
		{
			/* DONT SET EDITABLE TO FALSE ie set it to true */
		}
		/* for keys those who have different functionality in marathi and english keyboard */
		else
		{
			
			/* Here, we want functionality of key to alter, text area will be disabled untill the key is released*/
			ta.setEditable(false);
			if(key == 17) // control
			{
				prev_key = 17;
			}
			else if(key == ke.VK_CAPS_LOCK)// caps lock
			{		
				prev_key = ke.VK_CAPS_LOCK;
			}
			else if(key == ke.VK_SHIFT)
			{
				prev_key = ke.VK_SHIFT;
			}
			/*========================= For Combitional keys ====================================*/
			if(prev_key == ke.VK_SHIFT)
			{
				
				/* for combination of SHIFT + < 0 to 9 > */
				if( key >= 48 && key <= 57 ) 
				{
					if(key == ke.VK_1)					
						ta.insert(""+'\u090D',ta.getCaretPosition());
					else if(key == ke.VK_2)					
						ta.insert(""+'\u0945',ta.getCaretPosition());
					else if(key == ke.VK_3)					
						ta.insert(""+'\u0944',ta.getCaretPosition());
					else if(key == ke.VK_4)					
						ta.insert(""+'\u1CE4',ta.getCaretPosition());
					else if(key == ke.VK_5)					
						ta.insert(""+'\u091C'+'\u094D'+'\u091E',ta.getCaretPosition());
					else if(key == ke.VK_6)					
						ta.insert(""+'\u0924'+'\u094D'+'\u0930',ta.getCaretPosition());
					else if(key == ke.VK_7)					
						ta.insert(""+'\u0915'+'\u094D'+'\u0937',ta.getCaretPosition());
					else if(key == ke.VK_8)					
						ta.insert(""+'\u0936'+'\u094D'+'\u0930',ta.getCaretPosition());
					else if(key == ke.VK_9)					
						ta.insert("(",ta.getCaretPosition());
					else if(key == ke.VK_0)					
						ta.insert(")",ta.getCaretPosition());
				}
				/* for combination of SHIFT + < A to Z > */
				else if(key >= 65 && key <=  90)
				{
					if(key == ke.VK_Q)
						ta.insert(""+'\u094C',ta.getCaretPosition());		
					else if(key == ke.VK_W)
						ta.insert(""+'\u0948',ta.getCaretPosition());
					else if(key == ke.VK_E)
						ta.insert(""+'\u093E',ta.getCaretPosition());
					else if(key == ke.VK_R)
						ta.insert(""+'\u0940',ta.getCaretPosition() );
					else if(key == ke.VK_T)
						ta.insert(""+'\u0942',ta.getCaretPosition());
					else if(key == ke.VK_Y)
						ta.insert(""+'\u092C',ta.getCaretPosition());
					else if(key == ke.VK_U)
						ta.insert(""+'\u0939',ta.getCaretPosition());
					else if(key == ke.VK_I)
						ta.insert(""+'\u0917',ta.getCaretPosition());
					else if(key == ke.VK_O)
						ta.insert(""+'\u0926',ta.getCaretPosition());
					else if(key == ke.VK_P)
						ta.insert(""+'\u091C',ta.getCaretPosition());

					else if(key == ke.VK_A)
						ta.insert(""+'\u094A',ta.getCaretPosition());
					else if(key == ke.VK_S)
						ta.insert(""+'\u0947',ta.getCaretPosition());
					else if(key == ke.VK_D)
						ta.insert(""+'\u094D',ta.getCaretPosition());
					else if(key == ke.VK_F)
						ta.insert(""+'\u093F',ta.getCaretPosition());
					else if(key == ke.VK_G)
						ta.insert(""+'\u0941',ta.getCaretPosition());
					else if(key == ke.VK_H)
						ta.insert(""+'\u092A',ta.getCaretPosition());
					else if(key == ke.VK_J)
						ta.insert(""+'\u0930',ta.getCaretPosition());
					else if(key == ke.VK_K)
						ta.insert(""+'\u0915',ta.getCaretPosition());
					else if(key == ke.VK_L)
						ta.insert(""+'\u0924',ta.getCaretPosition());
	
					else if(key == ke.VK_Z)
						ta.insert(""+'\u0946',ta.getCaretPosition());
					else if(key == ke.VK_X)
						ta.insert(""+'\u0902',ta.getCaretPosition());		
					else if(key == ke.VK_C)
						ta.insert(""+'\u092E',ta.getCaretPosition());
					else if(key == ke.VK_V)
						ta.insert(""+'\u0928',ta.getCaretPosition());
					else if(key == ke.VK_B)
						ta.insert(""+'\u0935',ta.getCaretPosition());
					else if(key == ke.VK_N)
						ta.insert(""+'\u0932',ta.getCaretPosition());
					else if(key == ke.VK_M)
						ta.insert(""+'\u0938',ta.getCaretPosition());
				}
				/* for combination of SHIFT + < special key > */
				else
				{
					if(key == 45) // minus=45
						ta.insert(""+'\u0903',ta.getCaretPosition());
					
					else if(key == 61) //equal=61
						ta.insert(""+'\u090B',ta.getCaretPosition());
					else if(key == 92) //forward slash=45
						ta.insert(""+'\u0911',ta.getCaretPosition());
					else if(key == 192) //tilda=192
						ta.insert(""+'\u0912',ta.getCaretPosition());
					else if(key == 91) //opening bracket=91
						ta.insert(""+'\u0922',ta.getCaretPosition());
					else if(key == 93) //closing bracket=93
						ta.insert(""+'\u091E',ta.getCaretPosition());
					else if(key == 59) //semicolon=59
						ta.insert(""+'\u091B',ta.getCaretPosition());
					else if(key == 222) //single quote=222
						ta.insert(""+'\u0920',ta.getCaretPosition());
					else if(key == 44) //comma=44
						ta.insert(""+'\u0937',ta.getCaretPosition());
					else if(key == 46) //fullstop=46
						ta.insert(""+'\u0964',ta.getCaretPosition());
					else if(key == 47) //back slash=47
						ta.insert(""+'\u095F',ta.getCaretPosition());
				}
			} 
			else if(prev_key == 20)
			{
					if(key == 91) 
						ta.insert("[",ta.getCaretPosition());
					else if(key == 93) 
						ta.insert("]",ta.getCaretPosition());
					else if(key == 59) 
						ta.insert(";",ta.getCaretPosition());
					else if(key == 222) 
						ta.insert("'",ta.getCaretPosition());
					else if(key == 44) 
						ta.insert(",",ta.getCaretPosition());
					else if(key == 46) 
						ta.insert(".",ta.getCaretPosition());
					else if(key == 47) 
						ta.insert("/",ta.getCaretPosition());
					else if(key == 192) 
						ta.insert("`",ta.getCaretPosition());
					else if(key == 45) 
						ta.insert("-",ta.getCaretPosition());
					else if(key == 61)
						ta.insert("=",ta.getCaretPosition());
					else if(key == 92) 
						ta.insert("\\",ta.getCaretPosition());
			}
			else if(prev_key == 17)
			{
				/* for combination of CTRL + < 0 to 9 > */		
				if( key >= 48 && key <= 57 ) 
				{
					if(key == ke.VK_1)					
						ta.insert("!",ta.getCaretPosition());
					else if(key == ke.VK_2)					
						ta.insert("@",ta.getCaretPosition());
					else if(key == ke.VK_3  )					
						ta.insert("#",ta.getCaretPosition());
					else if(key == ke.VK_4)					
						ta.insert("$",ta.getCaretPosition());
					else if(key == ke.VK_5)					
						ta.insert("%",ta.getCaretPosition());
					else if(key == ke.VK_6)					
						ta.insert("^",ta.getCaretPosition());
					else if(key == ke.VK_7)					
						ta.insert("&",ta.getCaretPosition());
					else if(key == ke.VK_8)					
						ta.insert("*",ta.getCaretPosition());
					else if(key == ke.VK_9)					
						ta.insert("(",ta.getCaretPosition());
					else if(key == ke.VK_0)					
						ta.insert(")",ta.getCaretPosition());

				}
				/* for combination of CTRL + < special key > */
				else
				{
					if(key == 91) 
						ta.insert("{",ta.getCaretPosition());
					else if(key == 93) 
						ta.insert("}",ta.getCaretPosition());
					else if(key == 59) 
						ta.insert(":",ta.getCaretPosition());
					else if(key == 222) 
						ta.insert("\"",ta.getCaretPosition());
					else if(key == 44) 
						ta.insert("<",ta.getCaretPosition());
					else if(key == 46) 
						ta.insert(">",ta.getCaretPosition());
					else if(key == 47) 
						ta.insert("?",ta.getCaretPosition());
					else if(key == 192) 
						ta.insert("~",ta.getCaretPosition());
					else if(key == 45) 
						ta.insert("_",ta.getCaretPosition());
					else if(key == 61) 
						ta.insert("+",ta.getCaretPosition());
					else if(key == 92) 
						ta.insert("|",ta.getCaretPosition());
				}
			}
			/*========================= For non-combitional keys ====================================*/
			else
			{
				/* For A - Z keys */
				if( key >= 65 && key <=  90)	// A - Z
				{
					if(key == ke.VK_Q)
						ta.insert(""+'\u0914',ta.getCaretPosition());		
					else if(key == ke.VK_W)
						ta.insert(""+'\u090E',ta.getCaretPosition());
					else if(key == ke.VK_E)
						ta.insert(""+'\u0906',ta.getCaretPosition());
					else if(key == ke.VK_R)
						ta.insert(""+'\u0908',ta.getCaretPosition());
					else if(key == ke.VK_T)
						ta.insert(""+'\u090A',ta.getCaretPosition());
					else if(key == ke.VK_Y)
						ta.insert(""+'\u092D',ta.getCaretPosition());
					else if(key == ke.VK_U)
						ta.insert(""+'\u0919',ta.getCaretPosition());
					else if(key == ke.VK_I)
						ta.insert(""+'\u0918',ta.getCaretPosition());
					else if(key == ke.VK_O)
						ta.insert(""+'\u0927',ta.getCaretPosition());
					else if(key == ke.VK_P)
						ta.insert(""+'\u091D',ta.getCaretPosition());

					else if(key == ke.VK_A)
						ta.insert(""+'\u0913',ta.getCaretPosition());
					else if(key == ke.VK_S)
						ta.insert(""+'\u090F',ta.getCaretPosition());
					else if(key == ke.VK_D)
						ta.insert(""+'\u0905',ta.getCaretPosition());
					else if(key == ke.VK_F)
						ta.insert(""+'\u0907',ta.getCaretPosition());
					else if(key == ke.VK_G)
						ta.insert(""+'\u0909',ta.getCaretPosition());
					else if(key == ke.VK_H)
						ta.insert(""+'\u092B',ta.getCaretPosition());
					else if(key == ke.VK_J)
						ta.insert(""+'\u0931',ta.getCaretPosition());
					else if(key == ke.VK_K)
						ta.insert(""+'\u0916',ta.getCaretPosition());
					else if(key == ke.VK_L)
						ta.insert(""+'\u0925',ta.getCaretPosition());
	
					else if(key == ke.VK_Z)
						ta.insert(""+'\u0910',ta.getCaretPosition());
					else if(key == ke.VK_X)
						ta.insert(""+'\u0901',ta.getCaretPosition());		
					else if(key == ke.VK_C)
						ta.insert(""+'\u0923',ta.getCaretPosition());
					else if(key == ke.VK_V)
						ta.insert(""+'\u0929',ta.getCaretPosition());
					else if(key == ke.VK_B)
						ta.insert(""+'\u0934',ta.getCaretPosition());
					else if(key == ke.VK_N)
						ta.insert(""+'\u0933',ta.getCaretPosition());
					else if(key == ke.VK_M)
						ta.insert(""+'\u0936',ta.getCaretPosition());
				}
				/* For numeric keys 0 - 9 */
				else if( key >= 48 && key <= 57) // 0 - 9
				{
					if(key == ke.VK_0)
						ta.insert(""+'\u0966',ta.getCaretPosition());
					else if(key == ke.VK_1)
						ta.insert(""+'\u0967',ta.getCaretPosition());
					else if(key == ke.VK_2)
						ta.insert(""+'\u0968',ta.getCaretPosition());
					else if(key == ke.VK_3 )
						ta.insert(""+'\u0969',ta.getCaretPosition());
					else if(key == ke.VK_4)
						ta.insert(""+'\u096A',ta.getCaretPosition());
					else if(key == ke.VK_5)
						ta.insert(""+'\u096B',ta.getCaretPosition());
					else if(key == ke.VK_6)
						ta.insert(""+'\u096C',ta.getCaretPosition());
					else if(key == ke.VK_7)
						ta.insert(""+'\u096D',ta.getCaretPosition());
					else if(key == ke.VK_8)
						ta.insert(""+'\u096E',ta.getCaretPosition());
					else if(key == ke.VK_9)
						ta.insert(""+'\u096F',ta.getCaretPosition());
				}
				/* for numpad 0 - numpad 9 */
				else if( key >= 96 && key <= 105) // numpad 0 - numpad 9
				{
					if(key == 96)
						ta.insert(""+'\u0966',ta.getCaretPosition());
					else if(key == 97)
						ta.insert(""+'\u0967',ta.getCaretPosition());
					else if(key == 98)
						ta.insert(""+'\u0968',ta.getCaretPosition());
					else if(key == 99)
						ta.insert(""+'\u0969',ta.getCaretPosition());
					else if(key == 100)
						ta.insert(""+'\u096A',ta.getCaretPosition());
					else if(key == 101)
						ta.insert(""+'\u096B',ta.getCaretPosition());
					else if(key == 102)
						ta.insert(""+'\u096C',ta.getCaretPosition());
					else if(key == 103)
						ta.insert(""+'\u096D',ta.getCaretPosition());
					else if(key == 104)
						ta.insert(""+'\u096E',ta.getCaretPosition());
					else if(key == 105)
						ta.insert(""+'\u096F',ta.getCaretPosition());
				}
				/* for special keys */
				else
				{
					if(key == 61) //equal=61
						ta.insert(""+'\u0943',ta.getCaretPosition());
					else if(key == 45) //minus=45
						ta.insert("-",ta.getCaretPosition());
					else if(key == 92) //forward slash=45
						ta.insert(""+'\u0949',ta.getCaretPosition());
					else if(key == 192) //tilda=192
						ta.insert(""+'\u094A',ta.getCaretPosition());
					else if(key == 91) //opening bracket=91
						ta.insert(""+'\u0921',ta.getCaretPosition());
					else if(key == 93) //closing bracket=93
						ta.insert(""+'\u093C',ta.getCaretPosition());
					else if(key == 59) //semicolon=59
						ta.insert(""+'\u091A',ta.getCaretPosition());
					else if(key == 222) //single quote=222
						ta.insert(""+'\u091F',ta.getCaretPosition());
					else if(key == 44) //comma=44
						ta.insert(",",ta.getCaretPosition());
					else if(key == 46) //fullstop=46
						ta.insert(".",ta.getCaretPosition());
					else if(key == 47) //back slash=47
						ta.insert(""+'\u092F',ta.getCaretPosition());
					else if(key == 110) //numlock = On and '.' is pressed	
						ta.insert(".",ta.getCaretPosition());
				}
			}
		}

	}

	public void keyTyped(KeyEvent ke)
	{
	}
	public void keyReleased(KeyEvent ke)
	{
		try{
			sta = jtextarea_main[jtabbedpane_main.getSelectedIndex()];}
		catch(Exception e){}
		if(text_select_flag==2){
			ta=p.txt_projectName;
		}
		else if(text_select_flag==3){
			ta=c.tf1;
		}else if(text_select_flag==4){
			ta=c.tf;
		}
		else
			ta=sta;
		releasedkey = ke.getKeyCode();
		//System.out.println("Released key:: " + releasedkey);
		
		if(releasedkey==17 || releasedkey==20 || releasedkey== ke.VK_SHIFT)
		{
			prev_key = 0;
		}
		/* When keyReleased event is detected , set text area to true so that changes can be applied */
		ta.setEditable(true);
	}

	public static void main(String args[])
	{
		MainIDE m = new MainIDE();

	}
}
