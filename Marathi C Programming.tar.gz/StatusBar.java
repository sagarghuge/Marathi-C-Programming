/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ide;

/**
 *
 * @author abhijay
 */
import javax.swing.*;
import java.util.*;
class  StatusBar extends JToolBar implements Runnable
{
	private JLabel length,time;
	Thread t;
	String str;
	final String s[]={"Am","Pm"};
	Calendar c;
	JTextArea text;
	public void setLabels(String l,String t)
	{
		length.setText(" |||  Length  : "+l+" bytes.");
		time.setText(" |||  Time  : "+t);
	}
	StatusBar(JTextArea th)
	{
		super("StatusBar",JToolBar.HORIZONTAL);
		text=th;
		t = new Thread(this);
		setFloatable(false);

		time = new JLabel("Time :  ");
		length = new JLabel("Label : ");
		add(time);

		addSeparator();
		addSeparator();
		add(length);
		t.start();
	}
	public void run()
	{


		while(true)
		{
			String len = text.getText();
			c = Calendar.getInstance();
			str="";
			str=""+c.get(Calendar.HOUR)+" : "+c.get(Calendar.MINUTE)+" : "+c.get(Calendar.SECOND)+" "+s[c.get(Calendar.AM_PM)];
			setLabels(""+len.length(),str);
			try
			{
				Thread.sleep(100);
			}catch(Exception e){}
		}
	}
}

