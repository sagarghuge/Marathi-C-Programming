/*This program gives demo about the split mechanism that we want to perform on the errors*/
/* 1.Funtion will get the current string from the yytext according the rule in which it is rule id is there to define which pattern this string follows
the work of following functions is to identify characters on which the split is performed and grouping those characters to form the string.After it gets string arrays, it will just search for the match in all generated tables that is variable table and function table.The corresponding match will be placed specific positions in the maaped string and the final string will be returned.*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 9

/*Mapping Table which contains english and corresponding file name*/
struct MAP_TABLE
{
	char eng_name[50];
	char mar_name[50];
}mtable[50];

/*Rule table contains templates for all rules*/
struct Rule_table
{
	char rule [50];
}rtable[50];

/*Intialisation of the Mtable which will be changed to reading from the hard coded file*/
int init_MTABLE()
{
	strcpy(mtable[0].eng_name, "try");
	strcpy(mtable[0].mar_name, "प्रयत्न");
	strcpy(mtable[1].eng_name, "c");
	strcpy(mtable[1].mar_name, "म");
	strcpy(mtable[2].eng_name, "help");
	strcpy(mtable[2].mar_name, "मदत");
	strcpy(mtable[3].eng_name, "fun ");
	strcpy(mtable[3].mar_name, "मज्जा ");
	strcpy(mtable[4].eng_name, "random ");
	strcpy(mtable[4].mar_name, "काहीपण ");	
	strcpy(mtable[5].eng_name, " In function ");
	strcpy(mtable[5].mar_name, " क्रियेमध्ये ");
	strcpy(mtable[6].eng_name, "main");
	strcpy(mtable[6].mar_name, "ध्ये");
	strcpy(mtable[7].eng_name, "error");
	strcpy(mtable[7].mar_name, "मदध्ये");
	strcpy(mtable[8].eng_name, "undeclared (first use in this function)");
	strcpy(mtable[8].mar_name, "delcare kelele nahi.. :)");
}

char *digit[] = {"०","१","२","३","४","५","६","७","८","९"};

/*Initialisation of the Rule table which will be changes to readng from the hard coded template file*/
int init_rtable()
{
	strcpy(rtable[0].rule,".:");
	
	strcpy(rtable[1].rule,"‘’");
	
	strcpy(rtable[2].rule,".:::‘’:");

	strcpy(rtable[3].rule,".:‘’:");

	strcpy(rtable[4].rule,".::::‘’");
}

void init(char **allocate, int size)
{
	(*allocate) = (char *)malloc(size * sizeof(char));
	if(!(*allocate))
	{
		printf("Memory allocation failed.\n");
		exit(1);
	}
}

/*Function that is called to split the error sentence and translate it into corresponding marathi sentence*/
char *split(char *a,int rule_id)
{
	char split_char, *temp, *ret, *quote_l, *quote_r;
	int i =0, splchar_count=0, index=0, flag=0, split_flag=0;
	init(&quote_l, 1024);
	init(&quote_r, 1024);
	init(&temp, 128);
	init(&ret, 1024);

	strcpy(quote_l, "‘");
	strcpy(quote_r, "’");
	/*Initialisation of the Mtable*/
	init_MTABLE();
	init_rtable();
	
	split_char = ' ';
	ret[0] = '\0';
	
	while(split_char!='\0')
	{
		i = 0;
		split_flag=0;
		flag=0;
		/*Take out current rule and split the error template based on that */
		split_char = rtable[rule_id].rule[splchar_count++];

//		printf("Split_char --- %c a[index] -- %c -- ret = %s \n",split_char, a[index], ret);

		if(isdigit(a[index]))
		{
//			printf("am in..!!!\n");
			while(isdigit(a[index]))
			{
//				printf("Here : %s\n", digit[a[index]-'0']);
				strcat(ret, digit[a[index++] - '0']);				
			}
			index ++;
			temp[0] = split_char;
			temp[1] = '\0';
			strcat(ret, temp);
		}
		else
		{
			/*Take out the words depending on the split characters*/
			while(split_char != a[index])  //Bug notified check whether end of string need to checked
				temp[i++] = a[index++];
			temp[i] = '\0';
			printf("Here Temp is : ||%s||\n", temp);
			index++;

//			printf("In function should be here : **%s**\n", temp);

			/*Chegk whether the split character is ‘’ */
			if(split_char == quote_l[0] || split_char == quote_r[0])
			{
				printf("Am inside \n");
				splchar_count += 2;
				index += 2;
				flag = 1;
			}
			split_flag = 1;

			/*Check whether the english name is present in tha map table and whether the corresponding marathi name exist*/
			for(i=0; strcmp(temp,mtable[i].eng_name) != 0 && i < MAX; i++);

			/*Appending words taken out in the marathi in proper sequence*/
			if(i<MAX)
			{
				strcat(ret,mtable[i].mar_name);
			}
			else
				strcat(ret,temp);

			if(split_flag)
			{
				if(flag == 1)	
					strcat(ret," ‘");
				else
				{
					temp[0] = split_char;
					temp[1] = '\0';
					strcat(ret,temp);
				}
			}
		}
	}
	return ret;
}
