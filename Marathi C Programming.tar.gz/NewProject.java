/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.io.File;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.event.CaretListener;
import java.util.*;
/**
 *
 * @author sagar
 */
public class NewProject extends JFrame implements ActionListener,CaretListener
{
    
    String filepath;
    JLabel lbl_NameandLabel,lbl_projectLocation,lbl_projectName,lbl_projectFolder;
    JButton btn_Ok,btn_Cancel,btn_help;
    JTextField txt_projectLocation,txt_projectFolder;
    JTextArea txt_projectName;
    JCheckBox chk_setmainProject;
    MainIDE w;
    
    public  NewProject(MainIDE z)
    {
           Container cp = this.getContentPane();
           Dimension d;
           w = z;
           d = Toolkit.getDefaultToolkit().getScreenSize();
           int x=500,y=300;
           setLocation((int)(d.getWidth()-x)/2,((int)d.getHeight()-y)/2);
           lbl_NameandLabel = new JLabel("नाव अणि जागा :");
           lbl_projectFolder = new JLabel("प्रकल्प फोल्डर :");
           lbl_projectLocation = new JLabel("प्रकल्प जागा :");
           lbl_projectName = new JLabel("प्रकल्प नाव :");
           
           
           btn_Cancel = new JButton("रद्द करा");
           btn_Ok = new JButton("निर्माण करा");
           btn_help = new JButton("मदत");
           
          
           btn_Cancel.addActionListener(this);
           btn_Ok.addActionListener(this);
           btn_help.addActionListener(this);
           
           txt_projectFolder = new JTextField();
           txt_projectLocation = new JTextField();
           txt_projectName = new JTextArea(1,20);
           txt_projectName.setRows(1);
          // this.txt_projectName = tf;
           
           txt_projectName.addKeyListener(new KeyAdapter(){
         			public void keyPressed(KeyEvent ke){
				w.text_select_flag=2;
				w.keyPressed(ke);
         		    }
         			public void keyReleased(KeyEvent ke){
				w.keyReleased(ke);
         		    }
      			    });
           chk_setmainProject = new JCheckBox("मुख्य प्रकल्प स्थापित करा");
           setLayout(null);
           
           lbl_NameandLabel.setBounds(20,5,150,25);
           lbl_projectName.setBounds(20,50,150,25);
           lbl_projectLocation.setBounds(20,100,150,25);
           lbl_projectFolder.setBounds(20,150,150,25);
           
           chk_setmainProject.setBounds(20,225,200,25);
           
           txt_projectName.setBounds(170,50,250,25);
           txt_projectFolder.setBounds(170,150,250,25);
           txt_projectLocation.setBounds(170,100,250,25);
           
         
           
           btn_Ok.setBounds(290,330,100,25);
           btn_Cancel.setBounds(400,330,90,25);
           btn_help.setBounds(500,330,90,25);
           
           txt_projectName.setRequestFocusEnabled(true);
           
           cp.add(lbl_NameandLabel);
           cp.add(lbl_projectFolder);
           cp.add(lbl_projectLocation);
           cp.add(lbl_projectName);
           
          
           cp.add(btn_Cancel);
           cp.add(btn_Ok);
           cp.add(btn_help);
           
           cp.add(txt_projectFolder);
           cp.add(txt_projectLocation);
           cp.add(txt_projectName);
           cp.add(chk_setmainProject);
           
           try
           {
               File f = new File("");
               filepath = f.getAbsolutePath();
               
           }
           catch(Exception e)
           {
               e.printStackTrace(); 
           }
           txt_projectLocation.setText(filepath);
           txt_projectFolder.setText(filepath+"/");
           txt_projectName.addCaretListener(this);
           setSize(600,400);
           show();
           //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==btn_Cancel)
        {
            w.text_select_flag = 1;		
            this.dispose();
        }
        if(e.getSource()==btn_Ok)
        {
            if(txt_projectName.getText().equals(""))
            {
                JOptionPane.showMessageDialog(this, null,"नाव दाखिल करा",JOptionPane.ERROR_MESSAGE);
            }
            else
            {
                String dirName = txt_projectName.getText();
                File fdir = new File(txt_projectLocation.getText()+"/"+dirName);
                (new File("./मराठीप्रकल्प")).mkdir();
					w.path2=new String("./मराठीप्रकल्प/"+txt_projectName.getText());
                                        System.out.println(w.path2);
					if((new File("./मराठीप्रकल्प/"+txt_projectName.getText())).exists()){
                                            
					}else{
						
						(new File("./मराठीप्रकल्प/"+txt_projectName.getText()+"/मराठीस्रोत")).mkdirs();
						(new File("./मराठीप्रकल्प/"+txt_projectName.getText()+"/C कोड")).mkdirs();
						w.path2=new String("./मराठीप्रकल्प/"+txt_projectName.getText());
						w.save_flag_f[1]=0;
						w.sta=w.jtextarea_main[w.index];
						w.jscrollpane_tabbed = new JScrollPane(w.sta,w.v,w.h);
						
						w.jtabbedpane_main.add("अनामांकित"+w.index,w.jscrollpane_tabbed);
						w.track++;
						this.dispose();

            }
            w.text_select_flag = 1;
        }
        
    }
}
    @Override
    public void caretUpdate(CaretEvent e) {
        txt_projectFolder.setText(filepath+"/"+txt_projectName.getText());
        
    }
}
